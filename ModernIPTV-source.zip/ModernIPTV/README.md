# Modern IPTV (Android TV)

Простое IPTV-приложение для Android TV.

## Возможности
- Несколько M3U-плейлистов
- Избранные каналы
- Встроенный плеер (Media3 / ExoPlayer)
- Боковое меню (кнопка ←)
- Переключение каналов ↑ / ↓
- Голосовой поиск

## Сборка (без подписи)

1. Откройте папку `ModernIPTV` в Android Studio.
2. Дождитесь синхронизации Gradle.
3. Build → Build Bundle(s) / APK(s) → Build APK(s)
4. APK будет здесь:
   `app/build/outputs/apk/debug/app-debug.apk`

Или из терминала:
```bash
./gradlew assembleDebug
```

Debug APK подписывается автоматически стандартным debug-ключом Android Studio — его можно ставить на телевизор.

## Тестовый плейлист
```
https://iptv-org.github.io/iptv/countries/ru.m3u
```
