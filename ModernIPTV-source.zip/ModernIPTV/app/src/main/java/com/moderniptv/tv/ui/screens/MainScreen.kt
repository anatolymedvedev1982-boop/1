package com.moderniptv.tv.ui.screens

import android.content.Intent
import android.speech.RecognizerIntent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.key.*
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.ui.PlayerView
import com.moderniptv.tv.data.local.ChannelEntity
import com.moderniptv.tv.data.repository.IptvRepository
import com.moderniptv.tv.player.PlayerManager
import kotlinx.coroutines.launch

@Composable
fun MainScreen(
    repository: IptvRepository,
    playerManager: PlayerManager
) {
    val scope = rememberCoroutineScope()

    var channels by remember { mutableStateOf<List<ChannelEntity>>(emptyList()) }
    var favorites by remember { mutableStateOf<List<ChannelEntity>>(emptyList()) }
    var currentChannel by remember { mutableStateOf<ChannelEntity?>(null) }
    var showSideMenu by remember { mutableStateOf(true) }
    var showAddPlaylist by remember { mutableStateOf(false) }
    var searchQuery by remember { mutableStateOf("") }
    var searchResults by remember { mutableStateOf<List<ChannelEntity>>(emptyList()) }
    var selectedTab by remember { mutableStateOf(0) }

    val listState = rememberLazyListState()
    val focusRequester = remember { FocusRequester() }

    LaunchedEffect(Unit) {
        repository.getAllChannels().collect { channels = it }
    }
    LaunchedEffect(Unit) {
        repository.getFavorites().collect { favorites = it }
    }

    val voiceLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val spoken = result.data
            ?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            ?.firstOrNull()
        if (!spoken.isNullOrBlank()) {
            searchQuery = spoken
            selectedTab = 2
            scope.launch {
                searchResults = repository.searchChannels(spoken)
            }
        }
    }

    fun startVoiceSearch() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Назовите канал")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ru-RU")
        }
        try {
            voiceLauncher.launch(intent)
        } catch (_: Exception) {
        }
    }

    fun playChannel(channel: ChannelEntity) {
        currentChannel = channel
        playerManager.play(channel.url)
        showSideMenu = false
    }

    fun nextChannel() {
        val list = if (selectedTab == 0 && favorites.isNotEmpty()) favorites else channels
        if (list.isEmpty()) return
        val idx = list.indexOfFirst { it.id == currentChannel?.id }
        val nextIdx = if (idx < 0 || idx >= list.lastIndex) 0 else idx + 1
        playChannel(list[nextIdx])
    }

    fun prevChannel() {
        val list = if (selectedTab == 0 && favorites.isNotEmpty()) favorites else channels
        if (list.isEmpty()) return
        val idx = list.indexOfFirst { it.id == currentChannel?.id }
        val prevIdx = if (idx <= 0) list.lastIndex else idx - 1
        playChannel(list[prevIdx])
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
            .onKeyEvent { event ->
                if (event.type == KeyEventType.KeyUp) {
                    when (event.key) {
                        Key.DirectionUp -> {
                            if (!showSideMenu) {
                                prevChannel()
                                true
                            } else false
                        }
                        Key.DirectionDown -> {
                            if (!showSideMenu) {
                                nextChannel()
                                true
                            } else false
                        }
                        Key.DirectionLeft, Key.Menu, Key.Back -> {
                            showSideMenu = !showSideMenu
                            true
                        }
                        Key.DirectionRight -> {
                            if (showSideMenu) {
                                showSideMenu = false
                                true
                            } else false
                        }
                        else -> false
                    }
                } else false
            }
    ) {
        AndroidView(
            factory = { ctx ->
                PlayerView(ctx).apply {
                    player = playerManager.player
                    useController = false
                    keepScreenOn = true
                }
            },
            modifier = Modifier.fillMaxSize()
        )

        currentChannel?.let { ch ->
            Column(
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(24.dp)
                    .background(Color.Black.copy(alpha = 0.65f), RoundedCornerShape(8.dp))
                    .padding(12.dp)
            ) {
                Text(text = ch.name, color = Color.White, fontSize = 22.sp)
                ch.group?.let {
                    Text(text = it, color = Color.LightGray, fontSize = 14.sp)
                }
            }
        }

        if (showSideMenu) {
            Column(
                modifier = Modifier
                    .align(Alignment.CenterStart)
                    .fillMaxHeight()
                    .width(420.dp)
                    .background(Color(0xEE121212))
                    .padding(16.dp)
                    .focusRequester(focusRequester)
            ) {
                Text("Modern IPTV", color = Color.White, fontSize = 24.sp)
                Spacer(Modifier.height(12.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Избранное", "Все", "Поиск").forEachIndexed { index, title ->
                        val selected = selectedTab == index
                        Text(
                            text = title,
                            color = if (selected) Color.White else Color.Gray,
                            fontSize = 16.sp,
                            modifier = Modifier
                                .background(
                                    if (selected) Color(0xFF1E88E5) else Color(0xFF2A2A2A),
                                    RoundedCornerShape(20.dp)
                                )
                                .clickable { selectedTab = index }
                                .padding(horizontal = 14.dp, vertical = 8.dp)
                        )
                    }
                }

                Spacer(Modifier.height(12.dp))

                if (selectedTab == 2) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        OutlinedTextField(
                            value = searchQuery,
                            onValueChange = { q ->
                                searchQuery = q
                                scope.launch {
                                    searchResults = repository.searchChannels(q)
                                }
                            },
                            placeholder = { Text("Название канала…") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                        Spacer(Modifier.width(8.dp))
                        Button(onClick = { startVoiceSearch() }) {
                            Text("🎤")
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                }

                val displayList = when (selectedTab) {
                    0 -> favorites
                    2 -> searchResults
                    else -> channels
                }

                LazyColumn(
                    state = listState,
                    verticalArrangement = Arrangement.spacedBy(4.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    itemsIndexed(displayList, key = { _, c -> c.id }) { _, channel ->
                        val isCurrent = channel.id == currentChannel?.id
                        Card(
                            onClick = { playChannel(channel) },
                            colors = CardDefaults.cardColors(
                                containerColor = if (isCurrent) Color(0xFF1E88E5) else Color(0xFF1E1E1E)
                            ),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = channel.name,
                                        color = Color.White,
                                        fontSize = 16.sp,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    channel.group?.let {
                                        Text(
                                            text = it,
                                            color = Color.LightGray,
                                            fontSize = 12.sp,
                                            maxLines = 1
                                        )
                                    }
                                }
                                TextButton(onClick = {
                                    scope.launch { repository.toggleFavorite(channel.id) }
                                }) {
                                    Text("★", color = Color(0xFFFFD700), fontSize = 18.sp)
                                }
                            }
                        }
                    }
                }

                Spacer(Modifier.height(8.dp))
                Button(
                    onClick = { showAddPlaylist = true },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("+ Добавить плейлист")
                }
            }
        }

        if (showAddPlaylist) {
            AddPlaylistDialog(
                onDismiss = { showAddPlaylist = false },
                onAdd = { name, url ->
                    scope.launch {
                        repository.addPlaylist(name, url)
                        showAddPlaylist = false
                    }
                }
            )
        }
    }

    LaunchedEffect(showSideMenu) {
        if (showSideMenu) {
            try {
                focusRequester.requestFocus()
            } catch (_: Exception) {
            }
        }
    }
}

@Composable
fun AddPlaylistDialog(
    onDismiss: () -> Unit,
    onAdd: (name: String, url: String) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var url by remember { mutableStateOf("") }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.75f)),
        contentAlignment = Alignment.Center
    ) {
        Card(
            modifier = Modifier
                .width(500.dp)
                .padding(24.dp)
        ) {
            Column(modifier = Modifier.padding(24.dp)) {
                Text("Добавить плейлист", color = Color.White, fontSize = 20.sp)
                Spacer(Modifier.height(16.dp))
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Название") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = url,
                    onValueChange = { url = it },
                    label = { Text("URL M3U") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
                Spacer(Modifier.height(16.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Button(onClick = onDismiss) { Text("Отмена") }
                    Button(
                        onClick = {
                            if (url.isNotBlank()) {
                                onAdd(name.ifBlank { "Playlist" }, url)
                            }
                        },
                        enabled = url.isNotBlank()
                    ) {
                        Text("Добавить")
                    }
                }
            }
        }
    }
}
