package com.moderniptv.tv

import android.app.Application
import com.moderniptv.tv.data.local.AppDatabase
import com.moderniptv.tv.data.repository.IptvRepository

class ModernIptvApp : Application() {
    lateinit var database: AppDatabase
        private set
    lateinit var repository: IptvRepository
        private set

    override fun onCreate() {
        super.onCreate()
        database = AppDatabase.getInstance(this)
        repository = IptvRepository(database)
    }
}
