package com.moderniptv.tv.data.remote

import com.moderniptv.tv.data.local.ChannelEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit

class M3uParser {
    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()

    suspend fun parseFromUrl(url: String, playlistId: Long): List<ChannelEntity> =
        withContext(Dispatchers.IO) {
            val request = Request.Builder().url(url).build()
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) throw Exception("HTTP ${response.code}")
                val body = response.body?.string() ?: throw Exception("Empty body")
                parseContent(body, playlistId)
            }
        }

    fun parseContent(content: String, playlistId: Long): List<ChannelEntity> {
        val channels = mutableListOf<ChannelEntity>()
        var currentName = ""
        var currentLogo: String? = null
        var currentGroup: String? = null
        var currentTvgId: String? = null
        var number = 1

        for (line in content.lines()) {
            val trimmed = line.trim()
            when {
                trimmed.startsWith("#EXTINF:") -> {
                    currentLogo = extractAttr(trimmed, "tvg-logo")
                    currentGroup = extractAttr(trimmed, "group-title")
                    currentTvgId = extractAttr(trimmed, "tvg-id")
                    currentName = trimmed.substringAfterLast(",").trim()
                        .ifEmpty { "Channel $number" }
                }
                trimmed.isNotEmpty() && !trimmed.startsWith("#") -> {
                    channels.add(
                        ChannelEntity(
                            playlistId = playlistId,
                            name = currentName.ifEmpty { "Channel $number" },
                            url = trimmed,
                            logo = currentLogo,
                            group = currentGroup,
                            tvgId = currentTvgId,
                            number = number++
                        )
                    )
                    currentName = ""
                    currentLogo = null
                    currentGroup = null
                    currentTvgId = null
                }
            }
        }
        return channels
    }

    private fun extractAttr(line: String, attr: String): String? {
        val regex = """$attr="([^"]*)"""".toRegex()
        return regex.find(line)?.groupValues?.getOrNull(1)
    }
}
