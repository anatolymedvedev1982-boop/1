package com.moderniptv.tv.data.repository

import com.moderniptv.tv.data.local.*
import com.moderniptv.tv.data.remote.M3uParser
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first

class IptvRepository(
    private val db: AppDatabase,
    private val parser: M3uParser = M3uParser()
) {
    private val playlistDao = db.playlistDao()
    private val channelDao = db.channelDao()
    private val favoriteDao = db.favoriteDao()

    fun getPlaylists(): Flow<List<PlaylistEntity>> = playlistDao.getAll()
    fun getAllChannels(): Flow<List<ChannelEntity>> = channelDao.getAll()
    fun getFavorites(): Flow<List<ChannelEntity>> = channelDao.getFavorites()
    fun isFavorite(channelId: Long): Flow<Boolean> = favoriteDao.isFavorite(channelId)

    suspend fun addPlaylist(name: String, url: String): Result<Long> = runCatching {
        val id = playlistDao.insert(PlaylistEntity(name = name, url = url))
        val channels = parser.parseFromUrl(url, id)
        channelDao.insertAll(channels)
        id
    }

    suspend fun removePlaylist(id: Long) {
        channelDao.deleteByPlaylist(id)
        playlistDao.delete(id)
    }

    suspend fun toggleFavorite(channelId: Long) {
        val isFav = favoriteDao.isFavorite(channelId).first()
        if (isFav) favoriteDao.remove(channelId)
        else favoriteDao.add(FavoriteEntity(channelId))
    }

    suspend fun searchChannels(query: String): List<ChannelEntity> =
        if (query.isBlank()) emptyList() else channelDao.search(query)
}
