package com.moderniptv.tv

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.moderniptv.tv.player.PlayerManager
import com.moderniptv.tv.ui.screens.MainScreen
import com.moderniptv.tv.ui.theme.ModernIptvTheme

class MainActivity : ComponentActivity() {

    private lateinit var playerManager: PlayerManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val app = application as ModernIptvApp
        playerManager = PlayerManager(this)

        setContent {
            ModernIptvTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    MainScreen(
                        repository = app.repository,
                        playerManager = playerManager
                    )
                }
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        playerManager.release()
    }
}
